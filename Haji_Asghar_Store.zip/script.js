// Search functionality for products.html
function searchItems() {
  const searchBar = document.getElementById('searchBar');
  const filter = searchBar.value.toLowerCase();
  const items = document.querySelectorAll('.product-item');

  items.forEach((item) => {
    const itemName = item.getAttribute('data-name').toLowerCase();
    if (itemName.indexOf(filter) > -1) {
      item.style.display = '';
    } else {
      item.style.display = 'none';
    }
  });
}
